import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'share_draw_machine.dart';

/// Lưu trạng thái máy chia giải + dữ liệu phụ trợ, dùng file JSON (đồng
/// nhất với cách các service khác trong app lưu trữ). Port phần liên quan
/// tới jackpot/chia-giải của `Prefs.kt`.
class JackpotStorageService {
  static const _fileName = 'jackpot_prefs.json';

  Future<File> _getFile() async {
    final dir = await getApplicationDocumentsDirectory();
    return File('${dir.path}/$_fileName');
  }

  Future<Map<String, dynamic>> _readAll() async {
    try {
      final file = await _getFile();
      if (!await file.exists()) return {};
      final content = await file.readAsString();
      if (content.trim().isEmpty) return {};
      return jsonDecode(content) as Map<String, dynamic>;
    } catch (_) {
      return {};
    }
  }

  Future<void> _writeAll(Map<String, dynamic> data) async {
    final file = await _getFile();
    await file.writeAsString(jsonEncode(data));
  }

  Future<ShareDrawState> loadState() async {
    final data = await _readAll();
    final raw = data['state'] as Map<String, dynamic>?;
    return raw != null ? ShareDrawState.fromJson(raw) : ShareDrawState();
  }

  Future<void> saveState(ShareDrawState state) async {
    final data = await _readAll();
    data['state'] = state.toJson();
    await _writeAll(data);
  }

  /// Vài giá trị pot gần nhất (tối đa 6) — dùng để phát hiện pot reset.
  Future<List<int>> jackpotHistory() async {
    final data = await _readAll();
    final raw = data['jackpotHistory'] as List?;
    return raw?.map((e) => e as int).toList() ?? [];
  }

  Future<void> pushJackpot(int v) async {
    final data = await _readAll();
    final list = await jackpotHistory();
    list.add(v);
    final kept = list.length > 6 ? list.sublist(list.length - 6) : list;
    data['jackpotHistory'] = kept;
    await _writeAll(data);
  }

  Future<String?> get lastDrawId async => (await _readAll())['lastDrawId'] as String?;
  Future<void> setLastDrawId(String? v) async {
    final data = await _readAll();
    data['lastDrawId'] = v;
    await _writeAll(data);
  }

  Future<String> get lastStatus async =>
      (await _readAll())['lastStatus'] as String? ?? 'Chưa kiểm tra lần nào';
  Future<void> setLastStatus(String v) async {
    final data = await _readAll();
    data['lastStatus'] = v;
    await _writeAll(data);
  }

  Future<String> get lastDrawText async => (await _readAll())['lastDrawText'] as String? ?? '—';
  Future<void> setLastDrawText(String v) async {
    final data = await _readAll();
    data['lastDrawText'] = v;
    await _writeAll(data);
  }

  Future<int?> get lastJackpot async => (await _readAll())['lastJackpot'] as int?;
  Future<void> setLastJackpot(int v) async {
    final data = await _readAll();
    data['lastJackpot'] = v;
    await _writeAll(data);
  }

  Future<String> get lastSource async => (await _readAll())['lastSource'] as String? ?? '—';
  Future<void> setLastSource(String v) async {
    final data = await _readAll();
    data['lastSource'] = v;
    await _writeAll(data);
  }

  /// Cho phép dùng nguồn dự phòng khi vietlott.vn không vào được.
  /// MẶC ĐỊNH TẮT — app chỉ đọc trang chính thức.
  Future<bool> get useMirrors async => (await _readAll())['useMirrors'] as bool? ?? false;
  Future<void> setUseMirrors(bool v) async {
    final data = await _readAll();
    data['useMirrors'] = v;
    await _writeAll(data);
  }

  /// Bật/tắt từng loại thông báo. Mặc định BẬT scheduled/reminder/missed
  /// (đúng thứ người dùng cần biết), TẮT các loại phụ để đỡ làm phiền.
  bool _defaultFor(EventKind k) {
    switch (k) {
      case EventKind.scheduled:
      case EventKind.reminder:
      case EventKind.missed:
        return true;
      default:
        return false;
    }
  }

  Future<bool> isEnabled(EventKind k) async {
    final data = await _readAll();
    return data['notify_${k.name}'] as bool? ?? _defaultFor(k);
  }

  Future<void> setEnabled(EventKind k, bool on) async {
    final data = await _readAll();
    data['notify_${k.name}'] = on;
    await _writeAll(data);
  }
}

/// Máy trạng thái kỳ CHIA GIẢI Độc Đắc — port từ `ShareDrawMachine.kt`.
///
/// Thể lệ Vietlott: kết thúc một kỳ quay bất kỳ, nếu Độc Đắc VƯỢT 12 tỷ mà
/// không có người trúng, thì kỳ quay CUỐI CÙNG (21:00) của NGÀY LIỀN KỀ
/// TIẾP THEO được xác định là kỳ "Chia Giải Độc Đắc".
///
/// Mọi mốc thời gian đều tính theo GIỜ VIỆT NAM (UTC+7), không theo giờ máy.
library share_draw_machine;

enum EventKind { scheduled, reminder, cancelled, completed, scrapeFail, newDraw, missed }

class ShareDrawEvent {
  final EventKind kind;
  final String title;
  final String message;
  final bool urgent;

  ShareDrawEvent({
    required this.kind,
    required this.title,
    required this.message,
    this.urgent = false,
  });
}

class ShareDrawState {
  bool pending;
  String? shareDate; // yyyy-MM-dd
  bool reminded;
  int peakJackpot;
  String? triggerDrawId;
  String? triggerDrawDate;
  int prevJackpot;
  bool scrapeFailAlerted;

  ShareDrawState({
    this.pending = false,
    this.shareDate,
    this.reminded = false,
    this.peakJackpot = 0,
    this.triggerDrawId,
    this.triggerDrawDate,
    this.prevJackpot = 0,
    this.scrapeFailAlerted = false,
  });

  Map<String, dynamic> toJson() => {
        'pending': pending,
        'shareDate': shareDate,
        'reminded': reminded,
        'peakJackpot': peakJackpot,
        'triggerDrawId': triggerDrawId,
        'triggerDrawDate': triggerDrawDate,
        'prevJackpot': prevJackpot,
        'scrapeFailAlerted': scrapeFailAlerted,
      };

  factory ShareDrawState.fromJson(Map<String, dynamic> json) => ShareDrawState(
        pending: json['pending'] as bool? ?? false,
        shareDate: json['shareDate'] as String?,
        reminded: json['reminded'] as bool? ?? false,
        peakJackpot: json['peakJackpot'] as int? ?? 0,
        triggerDrawId: json['triggerDrawId'] as String?,
        triggerDrawDate: json['triggerDrawDate'] as String?,
        prevJackpot: json['prevJackpot'] as int? ?? 0,
        scrapeFailAlerted: json['scrapeFailAlerted'] as bool? ?? false,
      );
}

class ShareDrawMachine {
  static const thresholdVnd = 12000000000;
  static const shareDrawTime = '21:00';

  /// Ngày hôm nay theo giờ Việt Nam (UTC+7), bất kể múi giờ máy.
  static DateTime todayVn() {
    final nowUtc = DateTime.now().toUtc();
    final vn = nowUtc.add(const Duration(hours: 7));
    return DateTime(vn.year, vn.month, vn.day);
  }

  static String fmt(int? vnd) {
    if (vnd == null) return '?';
    final s = _thousands(vnd);
    if (vnd >= 1000000000) {
      final ty = (vnd / 1e9).toStringAsFixed(1);
      return '$s đ (~$ty tỷ)';
    }
    return '$s đ';
  }

  static String _thousands(int v) {
    final s = v.toString();
    final buf = StringBuffer();
    for (int i = 0; i < s.length; i++) {
      if (i > 0 && (s.length - i) % 3 == 0) buf.write('.');
      buf.write(s[i]);
    }
    return buf.toString();
  }

  static DateTime? _parseDate(String? s) {
    if (s == null || s.trim().isEmpty) return null;
    try {
      return DateTime.parse(s);
    } catch (_) {
      return null;
    }
  }

  static String _dm(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}';
  static String _dmy(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

  static ShareDrawEvent _reminderEvent(DateTime shareDate, int peak) => ShareDrawEvent(
        kind: EventKind.reminder,
        title: '🔔 TỐI NAY: kỳ CHIA GIẢI Độc Đắc Lotto 5/35!',
        message: 'Kỳ quay $shareDrawTime hôm nay (${_dmy(shareDate)}) là kỳ CHIA GIẢI. '
            'Độc Đắc ~${fmt(peak)} sẽ chia cho Giải Nhất (2/6) và Nhì/Ba/Tư/Năm '
            '(mỗi giải 1/6) nếu không ai trúng trực tiếp. Nhớ mua vé trước giờ quay!',
        urgent: true,
      );

  /// Cập nhật trạng thái sau mỗi lần cào. Trả danh sách sự kiện cần thông
  /// báo. `state` bị sửa TẠI CHỖ — người gọi lưu lại sau khi hàm trả về.
  static List<ShareDrawEvent> check({
    required ShareDrawState state,
    required int? jackpotVnd,
    required String? lastDrawId,
    required String? lastDrawDate,
    required List<int> recentJackpots,
  }) {
    final events = <ShareDrawEvent>[];
    final today = todayVn();

    // ── Cào thất bại ──────────────────────────────────────────────────
    if (jackpotVnd == null) {
      final sd = _parseDate(state.shareDate);
      if (state.pending && sd != null && _sameDate(today, sd) && !state.reminded) {
        state.reminded = true;
        events.add(_reminderEvent(sd, state.peakJackpot));
        return events;
      }
      if (!state.scrapeFailAlerted) {
        state.scrapeFailAlerted = true;
        events.add(ShareDrawEvent(
          kind: EventKind.scrapeFail,
          title: '⚠️ Không lấy được số Độc Đắc',
          message: 'Mọi nguồn tra cứu đều lỗi, kể cả trang chính thức. Tạm thời '
              'không tự xác định được kỳ CHIA GIẢI — kiểm tra thủ công '
              'trên vietlott.vn. Chỉ báo 1 lần cho tới khi tra cứu chạy lại.',
        ));
      }
      return events;
    }

    state.scrapeFailAlerted = false;

    // Phát hiện pot reset bằng lịch sử.
    final valid = recentJackpots.where((v) => v > 1000000000).toList();
    final last3 = valid.length >= 3 ? valid.sublist(valid.length - 3) : valid;
    final maxLast3 = last3.isEmpty ? 0 : last3.reduce((a, b) => a > b ? a : b);
    final droppedVsLog = valid.length >= 2 && jackpotVnd < maxLast3 * 0.92;

    if (state.pending) {
      final shareDate = _parseDate(state.shareDate);
      if (shareDate == null) {
        _resetTo(state, jackpotVnd);
        return events;
      }
      final peak = state.peakJackpot > 0 ? state.peakJackpot : 0;
      final prev = state.prevJackpot;
      final droppedVsPrev = prev > 0 && jackpotVnd < prev * 0.95;
      final droppedVsPeak = jackpotVnd < peak * 0.90;

      if (droppedVsPrev || droppedVsPeak || droppedVsLog) {
        if (!today.isAfter(shareDate)) {
          events.add(ShareDrawEvent(
            kind: EventKind.cancelled,
            title: '🚫 Huỷ kỳ chia giải Lotto 5/35',
            message: 'Đã có người trúng Độc Đắc (~${fmt(peak)}) trước kỳ chia giải '
                '${_dm(shareDate)}. Pot quay về ~6 tỷ.',
          ));
        } else {
          events.add(ShareDrawEvent(
            kind: EventKind.completed,
            title: '✅ Kỳ chia giải Lotto 5/35 đã diễn ra',
            message: 'Kỳ chia giải ngày ${_dmy(shareDate)} đã xong (pot trước chia '
                '~${fmt(peak)}). Pot hiện tại: ${fmt(jackpotVnd)}.',
          ));
        }
        _resetTo(state, jackpotVnd);
      } else {
        state.peakJackpot = peak > jackpotVnd ? peak : jackpotVnd;
        if (_sameDate(today, shareDate) && !state.reminded) {
          events.add(_reminderEvent(shareDate, state.peakJackpot));
          state.reminded = true;
        } else if (today.difference(shareDate).inDays > 2) {
          _resetTo(state, jackpotVnd); // du lieu tre bat thuong
        }
      }
    } else {
      if (droppedVsLog) {
        state.peakJackpot = jackpotVnd; // chu ky moi, khong cong don
      } else {
        state.peakJackpot = state.peakJackpot > jackpotVnd ? state.peakJackpot : jackpotVnd;
      }

      if (jackpotVnd > thresholdVnd) {
        final trigger = _parseDate(lastDrawDate) ?? today;
        final shareDate = trigger.add(const Duration(days: 1));
        state.pending = true;
        state.shareDate =
            '${shareDate.year.toString().padLeft(4, '0')}-${shareDate.month.toString().padLeft(2, '0')}-${shareDate.day.toString().padLeft(2, '0')}';
        state.reminded = false;
        state.triggerDrawId = lastDrawId;
        state.triggerDrawDate = trigger.toIso8601String();
        events.add(ShareDrawEvent(
          kind: EventKind.scheduled,
          title: '📅 Đã xác định kỳ CHIA GIẢI Lotto 5/35',
          message: 'Độc Đắc ${fmt(jackpotVnd)} đã vượt 12 tỷ sau kỳ '
              '#${lastDrawId ?? "?"}. Kỳ quay $shareDrawTime ngày '
              '${_dmy(shareDate)} là kỳ CHIA GIẢI.',
          urgent: true,
        ));
      }
    }

    state.prevJackpot = jackpotVnd;
    return events;
  }

  static bool _sameDate(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  static void _resetTo(ShareDrawState state, int jackpot) {
    state.pending = false;
    state.shareDate = null;
    state.reminded = false;
    state.peakJackpot = jackpot;
    state.triggerDrawId = null;
    state.triggerDrawDate = null;
    state.prevJackpot = jackpot;
    state.scrapeFailAlerted = false;
  }
}

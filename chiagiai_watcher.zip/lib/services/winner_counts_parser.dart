import '../models/draw.dart';

/// Bóc bảng số người trúng mỗi bậc giải (port từ WinnerCounts.kt).
class WinnerCountsParser {
  static final _ky = RegExp(r'#\s*(\d{3,6})');
  static final _tags = RegExp(
    r'<script[\s\S]*?</script>|<style[\s\S]*?</style>|<[^>]+>',
    caseSensitive: false,
  );

  // (khoá, tên bậc trong bảng). Tiền tố "giải" là TUỲ CHỌN.
  static const _tiers = [
    ['jackpot', 'độc đắc'],
    ['first', 'nhất'],
    ['second', 'nhì'],
    ['third', 'ba'],
    ['fourth', 'tư'],
    ['fifth', 'năm'],
    ['kk', 'kk'],
  ];

  static String _clean(String html) {
    return _tags.replaceAll(html, ' ').replaceAll(RegExp(r'\s+'), ' ');
  }

  static WinnerCounts? parse(String html) {
    final t = _clean(html);
    final kyMatch = _ky.firstMatch(t);
    if (kyMatch == null) return null;
    final drawId = kyMatch.group(1)!.padLeft(5, '0');
    final low = t.toLowerCase();

    final vals = <String, int>{};
    for (final tier in _tiers) {
      final key = tier[0];
      final name = tier[1];
      final re = RegExp(
        r'(?:gi[ải]+\s+)?' + RegExp.escape(name) + r'\b[^\d]{0,20}([\d.,]+)\s+([\d.,]{4,})',
      );
      final m = re.firstMatch(low);
      if (m == null) continue;
      final digits = m.group(1)!.replaceAll(RegExp(r'\D'), '');
      final n = int.tryParse(digits);
      if (n == null) continue;
      vals[key] = n;
    }
    if (vals.isEmpty) return null;
    return WinnerCounts(
      drawId: drawId,
      jackpot: vals['jackpot'] ?? -1,
      first: vals['first'] ?? -1,
      second: vals['second'] ?? -1,
      third: vals['third'] ?? -1,
      fourth: vals['fourth'] ?? -1,
      fifth: vals['fifth'] ?? -1,
      kk: vals['kk'] ?? -1,
    );
  }
}

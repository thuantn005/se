import 'package:workmanager/workmanager.dart';

import 'jackpot_check_service.dart';

const String kJackpotCheckTask = 'jackpot_check_task';

/// Điểm vào cho isolate nền — BẮT BUỘC là top-level function hoặc static,
/// đánh dấu @pragma để Flutter không tree-shake mất khi build release.
@pragma('vm:entry-point')
void backgroundCallbackDispatcher() {
  Workmanager().executeTask((task, inputData) async {
    if (task == kJackpotCheckTask) {
      final ok = await JackpotCheckService.runCheck();
      return ok;
    }
    return true;
  });
}

/// Đăng ký kiểm tra nền định kỳ. WorkManager tự lo việc sống sót qua khởi
/// động lại máy, không cần BroadcastReceiver riêng như bên native.
///
/// LƯU Ý: khoảng lặp tối thiểu của WorkManager là 15 phút, nhưng để đỡ tốn
/// pin/dữ liệu và vì kỳ quay chỉ có 2 mốc cố định mỗi ngày (13:00, 21:00),
/// dùng chu kỳ 3 tiếng — đủ bắt kịp cả 2 kỳ trong ngày mà không cào quá dày.
class JackpotBackgroundService {
  static Future<void> initialize() async {
    await Workmanager().initialize(backgroundCallbackDispatcher);
    await Workmanager().registerPeriodicTask(
      kJackpotCheckTask,
      kJackpotCheckTask,
      frequency: const Duration(hours: 3),
      constraints: Constraints(networkType: NetworkType.connected),
      existingWorkPolicy: ExistingPeriodicWorkPolicy.keep,
    );
  }

  /// Kiểm tra ngay (bấm tay trên app), chạy trực tiếp trên UI isolate,
  /// không qua WorkManager.
  static Future<bool> checkNow() => JackpotCheckService.runCheck();
}

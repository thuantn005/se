import '../models/draw.dart';

/// Bóc kỳ quay ra khỏi HTML trang kết quả.
///
/// PORT NGUYÊN VĂN từ `DrawParser.kt` (app native Android đã kiểm chứng
/// thực tế nhiều tháng). Giữ đúng logic: THÀ TRẢ VỀ NULL/RỖNG còn hơn hiện
/// một dãy số sai — người dùng có thể dò vé theo số bịa nếu parser đoán
/// nhầm, hậu quả nghiêm trọng hơn nhiều so với việc tạm thời không có số.
class DrawParser {
  static final _ky = RegExp(r'#\s*(\d{3,6})');
  static final _date = RegExp(r'(\d{2})[/-](\d{2})[/-](\d{4})');
  static final _balls = RegExp(r'\b(0[1-9]|[12]\d|3[0-5])\b');
  static final _pipeForm = RegExp(r'((?:\d\s*){10})\|\s*((?:\d\s*){2})');
  static final _specialToken = RegExp(r'\b(0[1-9]|1[0-2])\b');

  static const _mainMin = 1;
  static const _mainMax = 35;
  static const _specialMin = 1;
  static const _specialMax = 12;

  /// Những thứ TRÔNG như số xổ số nhưng không phải, phải xoá trước khi dò.
  static final _noise = [
    RegExp(r'\d{1,4}[/-]\d{1,2}[/-]\d{1,4}'), // 09/08/2026
    RegExp(r'\b\d{1,2}\s*[:h]\s*\d{2}\b'), // 13:00, 21h00
    RegExp(r'[\d][\d.,]{8,}'), // 6.648.422.500 (tiền)
    RegExp(r'#\s*\d{3,6}'), // chính mã kỳ
  ];

  static String _stripNoise(String s) {
    var out = s;
    for (final r in _noise) {
      out = out.replaceAllMapped(r, (m) => ' ' * m.group(0)!.length);
    }
    return out;
  }

  static String _stripTags(String html) {
    return html
        .replaceAll(RegExp(r'<script[\s\S]*?</script>', caseSensitive: false), ' ')
        .replaceAll(RegExp(r'<style[\s\S]*?</style>', caseSensitive: false), ' ')
        .replaceAll(RegExp(r'<[^>]+>'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ');
  }

  static String _dateOf(String text) {
    final m = _date.firstMatch(text);
    if (m == null) return '';
    return '${m.group(3)}-${m.group(2)}-${m.group(1)}';
  }

  /// Bóc MỌI kỳ đọc được trên trang, sắp xếp tăng dần theo mã kỳ.
  static List<Draw> parseAll(String html) {
    final text = _stripTags(html);
    final out = <String, Draw>{};
    for (final ky in _ky.allMatches(text)) {
      final drawId = ky.group(1)!.padLeft(5, '0');
      if (out.containsKey(drawId)) continue;
      final from = ky.end;
      final d = _parsePipeForm(text, from, drawId) ?? _parseTokenForm(text, from, drawId);
      if (d != null) out[drawId] = d;
    }
    final list = out.values.toList()..sort((a, b) => a.drawId.compareTo(b.drawId));
    return list;
  }

  static Draw? parseLatest(String html) {
    final all = parseAll(html);
    return all.isEmpty ? null : all.last;
  }

  static Draw? _parseTokenForm(String text, int from, String drawId) {
    final end = (from + 400).clamp(0, text.length);
    if (from > text.length) return null;
    final window = _stripNoise(text.substring(from, end));

    final hits = _balls.allMatches(window).take(5).toList();
    if (hits.length < 5) return null;
    final main = hits.map((h) => int.parse(h.group(0)!)).toList()..sort();
    if (main.toSet().length != 5) return null;

    if (hits[4].end - hits[0].start > 200) return null;

    final afterStart = (hits[4].end + 1).clamp(0, window.length);
    final afterMain = window.substring(afterStart);
    final spMatch = _specialToken.firstMatch(afterMain);
    final special = spMatch != null ? int.tryParse(spMatch.group(0)!) : null;
    if (special == null || special < 1 || special > 12) return null;

    return Draw(drawId: drawId, drawDate: _dateOf(text), numbers: main, special: special);
  }

  static Draw? _parsePipeForm(String text, int from, String drawId) {
    final end = (from + 300).clamp(0, text.length);
    if (from > text.length) return null;
    final window = text.substring(from, end);
    final m = _pipeForm.firstMatch(window);
    if (m == null) return null;

    final digits = m.group(1)!.replaceAll(RegExp(r'\D'), '');
    final spDigits = m.group(2)!.replaceAll(RegExp(r'\D'), '');
    if (digits.length != 10 || spDigits.length != 2) return null;

    final main = <int>[];
    for (int i = 0; i < 10; i += 2) {
      main.add(int.parse(digits.substring(i, i + 2)));
    }
    main.sort();
    if (main.toSet().length != 5) return null;
    if (main.any((n) => n < _mainMin || n > _mainMax)) return null;

    final special = int.parse(spDigits);
    if (special < _specialMin || special > _specialMax) return null;

    return Draw(drawId: drawId, drawDate: _dateOf(text), numbers: main, special: special);
  }
}

/// Bóc giá trị Độc Đắc ra khỏi HTML.
///
/// PORT NGUYÊN VĂN từ `JackpotParser.kt` — cùng nhãn, cùng danh sách decoy,
/// cùng cửa sổ 200 ký tự, cùng cách gắn mã kỳ, cùng luật kiểm định theo kỳ.
/// Giữ giống hệt là có chủ đích: parser gốc đã chạy thật nhiều tháng trên
/// xosominhngoc và minhchinh, mọi khác biệt ở đây đều là rủi ro thuần túy.
class JackpotResult {
  final int? amountVnd;
  final String? drawId;
  JackpotResult(this.amountVnd, this.drawId);
}

class JackpotParser {
  static const _minVnd = 1000000000;
  static const _maxVnd = 500000000000;
  static const _labelWindow = 200;

  static const _labels = ['độc đắc', 'doc dac', 'jackpot'];

  /// Cụm báo hiệu con số KHÔNG phải pot hiện tại (ước tính, doanh thu…).
  static const _decoys = [
    'ước tính', 'uoc tinh', 'kỳ tới', 'ky toi', 'dự kiến', 'du kien',
    'doanh thu', 'doanh số', 'doanh so', 'tổng giá trị', 'luỹ kế', 'lũy kế',
  ];

  static final _money =
      RegExp(r'([\d][\d.,]{8,})(?:\s*(?:đồng|dong|vnd))?', caseSensitive: false);
  static final _ky = RegExp(r'#\s*(\d{3,6})');

  static List<int> _labelPositions(String low) {
    final out = <int>[];
    for (final label in _labels) {
      var i = low.indexOf(label);
      while (i >= 0) {
        out.add(i);
        i = low.indexOf(label, i + 1);
      }
    }
    out.sort();
    return out;
  }

  /// Mã kỳ '#NNNNN' gần nhất đứng TRƯỚC vị trí pos.
  static String? _drawIdBefore(String html, int pos) {
    String? best;
    for (final m in _ky.allMatches(html)) {
      if (m.start < pos) {
        best = m.group(1);
      } else {
        break;
      }
    }
    return best;
  }

  static JackpotResult extract(String html, [String? expectedDrawId]) {
    final low = html.toLowerCase();
    final labels = _labelPositions(low);

    // (giá trị, khoảng cách tới nhãn, kỳ)
    final candidates = <List<dynamic>>[]; // [int amount, int dist, String? drawId]

    for (final m in _money.allMatches(html)) {
      final raw = m.group(1)!;
      if (!raw.contains('.') && !raw.contains(',')) continue;
      final digits = raw.replaceAll(RegExp(r'\D'), '');
      if (digits.isEmpty) continue;
      final v = int.tryParse(digits);
      if (v == null) continue;
      if (v < _minVnd || v > _maxVnd) continue;

      final pos = m.start;
      final matchLower = m.group(0)!.toLowerCase().trimRight();
      final hasUnit = matchLower.endsWith('đồng') ||
          matchLower.endsWith('dong') ||
          matchLower.endsWith('vnd');

      if (labels.isEmpty) {
        if (hasUnit) {
          candidates.add([v, 1 << 30, _drawIdBefore(html, pos)]);
        }
        continue;
      }

      final preceding = labels.where((l) => pos - l >= 0 && pos - l <= _labelWindow).toList();
      if (preceding.isEmpty) continue;
      final nearest = preceding.reduce((a, b) => a > b ? a : b);
      final between = low.substring(nearest, pos);
      if (_decoys.any((d) => between.contains(d))) continue;
      candidates.add([v, pos - nearest, _drawIdBefore(html, pos)]);
    }

    if (candidates.isEmpty) return JackpotResult(null, null);

    // KIỂM ĐỊNH THEO KỲ: loại ứng viên có kỳ CŨ hơn kỳ đã biết, ưu tiên
    // ứng viên khớp đúng kỳ; nếu không còn ứng viên hợp lệ thì trả rỗng —
    // thà không có số còn hơn hành động trên số cũ.
    final exp = expectedDrawId != null ? int.tryParse(expectedDrawId) : null;
    List<List<dynamic>> pool;
    if (exp == null) {
      pool = candidates;
    } else {
      final valid = candidates.where((c) {
        final ky = c[2] != null ? int.tryParse(c[2] as String) : null;
        return ky == null || ky >= exp;
      }).toList();
      final exact = valid.where((c) {
        final ky = c[2] != null ? int.tryParse(c[2] as String) : null;
        return ky == exp;
      }).toList();
      pool = exact.isNotEmpty ? exact : valid;
      if (pool.isEmpty) return JackpotResult(null, null);
    }

    // Nhãn gần nhất thắng; hoà khoảng cách thì lấy giá trị lớn hơn.
    pool.sort((a, b) {
      final distCompare = (a[1] as int).compareTo(b[1] as int);
      if (distCompare != 0) return distCompare;
      return (b[0] as int).compareTo(a[0] as int);
    });
    final best = pool.first;
    return JackpotResult(best[0] as int, best[2] as String?);
  }
}

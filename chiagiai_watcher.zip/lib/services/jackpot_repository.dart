import 'dart:io';
import 'package:http/http.dart' as http;

import '../models/draw.dart';
import 'draw_parser.dart';
import 'jackpot_parser.dart';
import 'winner_counts_parser.dart';

/// Nguồn dữ liệu — port từ `Sources.kt`.
class JackpotSources {
  static const official = [
    'https://vietlott.vn/vi/trung-thuong/ket-qua-trung-thuong/535',
    'https://vietlott.vn/vi/choi/lotto535/gioi-thieu-san-pham-535',
  ];

  /// Nguồn dự phòng, MẶC ĐỊNH TẮT — chỉ bật khi vietlott.vn không vào được.
  static const mirrors = [
    'https://xosominhngoc.net.vn/kqxs-lotto-535',
    'https://www.minhchinh.com/xo-so-dien-toan-lotto-535.html',
  ];

  static const winnerCountSources = [
    'https://www.minhchinh.com/truc-tiep-xo-so-tu-chon-lotto-535.html',
    'https://www.minhchinh.com/xo-so-dien-toan-lotto-535.html',
  ];

  static const userAgent = 'Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 '
      '(KHTML, like Gecko) Chrome/131.0.0.0 Mobile Safari/537.36';
  static const acceptLanguage = 'vi-VN,vi;q=0.9';
}

/// Cào + parse dữ liệu Lotto 5/35 — port từ `Repository.kt`.
///
/// Nguyên tắc giữ nguyên: dữ liệu nào không chắc thì KHÔNG trả về. Thà hiện
/// "không đọc được dãy số" còn hơn hiện một dãy số bịa.
class JackpotRepository {
  static const _timeout = Duration(seconds: 20);

  static Future<String> _fetch(String url) async {
    final resp = await http.get(
      Uri.parse(url),
      headers: {
        'User-Agent': JackpotSources.userAgent,
        'Accept-Language': JackpotSources.acceptLanguage,
        'Accept': 'text/html,application/json;q=0.9,*/*;q=0.8',
      },
    ).timeout(_timeout);
    if (resp.statusCode < 200 || resp.statusCode >= 300) {
      throw HttpException('HTTP ${resp.statusCode}');
    }
    return resp.body;
  }

  /// Cào trang chính thức (mirror chỉ chạy khi [allowMirrors] bật).
  static Future<Snapshot> scrape({bool allowMirrors = false}) async {
    int? jackpot;
    String? jackpotKy;
    String? jackpotSrc;
    Draw? draw;
    List<Draw> draws = const [];
    String? drawSrc;
    final errors = <String>[];

    final urls = allowMirrors
        ? [...JackpotSources.official, ...JackpotSources.mirrors]
        : JackpotSources.official;

    for (final url in urls) {
      if (jackpot != null && draw != null) break;
      final host = Uri.tryParse(url)?.host ?? url;
      try {
        final html = await _fetch(url);

        if (draw == null) {
          final found = DrawParser.parseAll(html);
          if (found.isNotEmpty) {
            draws = found;
            draw = found.last;
            drawSrc = host;
          } else {
            errors.add('$host: tải được trang nhưng không đọc chắc chắn được dãy số');
          }
        }

        if (jackpot == null) {
          final r = JackpotParser.extract(html, draw?.drawId);
          if (r.amountVnd != null) {
            jackpot = r.amountVnd;
            jackpotKy = r.drawId;
            jackpotSrc = host;
          }
        }
      } catch (e) {
        errors.add('$host: $e');
      }
    }

    if (jackpot == null && draw == null && errors.isEmpty) {
      errors.add('vietlott.vn: không trả về dữ liệu dùng được');
    }

    return Snapshot(
      jackpotVnd: jackpot,
      jackpotDrawId: jackpotKy,
      latestDraw: draw,
      draws: draws,
      jackpotSource: jackpotSrc,
      drawSource: drawSrc,
      errors: errors,
    );
  }

  /// Cào bảng số người trúng mỗi bậc giải (minhchinh.com).
  static Future<WinnerCounts?> fetchWinnerCounts() async {
    for (final url in JackpotSources.winnerCountSources) {
      try {
        final wc = WinnerCountsParser.parse(await _fetch(url));
        if (wc != null && wc.hasCore) return wc;
      } catch (_) {
        // thử nguồn tiếp theo
      }
    }
    return null;
  }
}

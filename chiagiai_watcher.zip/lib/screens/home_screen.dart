import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import '../services/background_service.dart';
import '../services/jackpot_storage_service.dart';
import '../services/share_draw_machine.dart';
import '../theme/app_theme.dart';
import 'settings_screen.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _storage = JackpotStorageService();
  bool _checking = false;

  String _lastDrawText = '—';
  String _lastStatus = 'Chưa kiểm tra lần nào';
  String _lastSource = '—';
  int? _lastJackpot;
  ShareDrawState? _state;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final drawText = await _storage.lastDrawText;
    final status = await _storage.lastStatus;
    final source = await _storage.lastSource;
    final jackpot = await _storage.lastJackpot;
    final state = await _storage.loadState();
    if (!mounted) return;
    setState(() {
      _lastDrawText = drawText;
      _lastStatus = status;
      _lastSource = source;
      _lastJackpot = jackpot;
      _state = state;
    });
  }

  Future<void> _checkNow() async {
    setState(() => _checking = true);
    try {
      await JackpotBackgroundService.checkNow();
    } catch (_) {
      // trang thai loi da duoc luu, se hien qua _lastStatus sau khi _load()
    }
    await _load();
    if (mounted) setState(() => _checking = false);
  }

  @override
  Widget build(BuildContext context) {
    final state = _state;
    final pending = state?.pending ?? false;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Săn Chia Giải'),
        actions: [
          IconButton(
            icon: const Icon(Icons.settings),
            onPressed: () async {
              await Navigator.push(
                context,
                MaterialPageRoute(builder: (_) => const SettingsScreen()),
              );
              _load();
            },
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: _checkNow,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _buildLatestDrawCard(),
            const SizedBox(height: 14),
            if (pending) _buildPendingCard(state!),
            if (pending) const SizedBox(height: 14),
            _buildStatusFooter(),
            const SizedBox(height: 20),
            Center(
              child: ElevatedButton.icon(
                onPressed: _checking ? null : _checkNow,
                icon: _checking
                    ? const SizedBox(
                        width: 16,
                        height: 16,
                        child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white),
                      )
                    : const Icon(Icons.refresh),
                label: Text(_checking ? 'Đang kiểm tra...' : 'Kiểm tra ngay'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.luckyRed,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLatestDrawCard() {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.cardIvory,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: AppColors.gold.withOpacity(0.5)),
        boxShadow: [
          BoxShadow(color: Colors.black.withOpacity(0.06), blurRadius: 8, offset: const Offset(0, 3)),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'KỲ MỚI NHẤT',
            style: GoogleFonts.baloo2(
              fontSize: 13,
              fontWeight: FontWeight.w700,
              color: AppColors.muted,
              letterSpacing: 1,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            _lastDrawText,
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w700),
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            decoration: BoxDecoration(
              color: AppColors.luckyRed.withOpacity(0.08),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Row(
              children: [
                const Icon(Icons.emoji_events, color: AppColors.gold, size: 22),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Giá trị Độc Đắc',
                          style: TextStyle(fontSize: 11, color: AppColors.muted)),
                      Text(
                        ShareDrawMachine.fmt(_lastJackpot),
                        style: const TextStyle(
                          fontSize: 17,
                          fontWeight: FontWeight.w800,
                          color: AppColors.luckyRed,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPendingCard(ShareDrawState state) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.gold.withOpacity(0.15),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppColors.gold),
      ),
      child: Row(
        children: [
          const Icon(Icons.celebration, color: AppColors.luckyRed, size: 28),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Đã xác định kỳ CHIA GIẢI',
                  style: GoogleFonts.baloo2(fontWeight: FontWeight.w700, fontSize: 14),
                ),
                const SizedBox(height: 2),
                Text(
                  'Kỳ quay 21:00 ngày ${state.shareDate ?? "?"}',
                  style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                ),
                Text(
                  'Đỉnh Độc Đắc trước chia: ${ShareDrawMachine.fmt(state.peakJackpot)}',
                  style: TextStyle(fontSize: 11.5, color: AppColors.muted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatusFooter() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(_lastStatus, style: TextStyle(fontSize: 11.5, color: AppColors.muted)),
        const SizedBox(height: 2),
        Text('Nguồn: $_lastSource', style: TextStyle(fontSize: 10.5, color: AppColors.muted)),
      ],
    );
  }
}
